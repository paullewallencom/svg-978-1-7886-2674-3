import React, { Component } from 'react';

class ReactRect extends Component {
  render() {
    return (
      <rect x="125" y="125" width="10" height="10" stroke="blue" fill="none"></rect>

    );
  }
}

export default ReactRect;
